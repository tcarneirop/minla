#ifndef HEURISTIC_H
#define HEURISTIC_H

#include "grafo.h"

class Heuristic{
public:
    Grafo *grafo;
    Heuristic(Grafo *g):grafo(g){}

};




#endif // HEURISTIC_H
