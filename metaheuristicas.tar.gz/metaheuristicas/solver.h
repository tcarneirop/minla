#ifndef SOLVER_H
#define SOLVER_H


class Solver {
public:
    virtual int solve(int tag[]) = 0;

};

#endif // SOLVER_H
