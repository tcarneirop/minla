#ifndef CLIMBER_H
#define CLIMBER_H


class Climber {
public:
    virtual int climb(int output[], int custo) = 0;
};

#endif // CLIMBER_H
